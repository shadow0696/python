from tkinter import *

window = Tk()
window.geometry('340x400')
window.title('calculator')

e = Entry(window,bd=0,justify=RIGHT,font=('bold',20),bg='white')
e.place(x=0,y=0,height=60,width=340)

def click(num):
    re = e.get()
    e.delete(0,END)
    e.insert(0,str(re)+str(num))



b = Button(window,text="1",width=8,command=lambda:click(1))
b.place(x=15,y=60)

b = Button(window,text="2",width=8,command=lambda:click(2))
b.place(x=125,y=60)


b = Button(window,text="3",width=8,command=lambda:click(3))
b.place(x=230,y=60)


b = Button(window,text="4",width=8,command=lambda:click(4))
b.place(x=15,y=120)

b = Button(window,text="5",width=8,command=lambda:click(5))
b.place(x=125,y=120)

b = Button(window,text="6",width=8,command=lambda:click(6))
b.place(x=230,y=120)

b = Button(window,text="7",width=8,command=lambda:click(7))
b.place(x=15,y=180)

b = Button(window,text="8",width=8,command=lambda:click(8))
b.place(x=125,y=180)

b = Button(window,text="9",width=8,command=lambda:click(9))
b.place(x=230,y=180)

b = Button(window,text="0",width=8,command=lambda:click(0))
b.place(x=125,y=240)

def add():
    n1 = e.get()
    global math
    math = "add"
    global i
    i = int(n1)
    e.delete(0,END)


b = Button(window,text="+",width=8,command=add)
b.place(x=15,y=240)

def sub():
    n1 = e.get()
    global math
    math = "sub"
    global i
    i = int(n1)
    e.delete(0,END)

b = Button(window,text="-",width=8,command=sub)
b.place(x=230,y=240)

def mul():
    n1 = e.get()
    global math
    math = "mul"
    global i
    i = int(n1)
    e.delete(0,END)


b = Button(window,text="x",width=8,command=mul)
b.place(x=15,y=300)

def div():
    n1 = e.get()
    global math
    math = "div" 
    global i
    i = int(n1)
    e.delete(0,END)


b = Button(window,text="/",width=8,command=div)
b.place(x=125,y=300)

def re():
    n2 = e.get()
    e.delete(0,END)
    if math == "add":
        e.insert(0,i + int(n2))
    elif math == "sub":
        e.insert(0,i - int(n2))
    elif math == "mul":
        e.insert(0,i * int(n2))
    elif math == "div":
        e.insert(0,i / int(n2))

b = Button(window,text="=",width=8,command=re)
b.place(x=230,y=300)

def clear():
    e.delete(0,END)

b = Button(window,text="C",width=8,command=clear)
b.place(x=125,y=360)

mainloop()

